package com.cg.bank.pl;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.bank.bean.BankBean;
import com.cg.bank.exception.BankException;
import com.cg.bank.service.BankServiceImpl;
import com.cg.bank.service.IBankService;


public class BankMain {
	
	static Scanner scan=new Scanner(System.in);
	static IBankService bankService = null;
	static BankServiceImpl bankServiceImpl = null;
	static Logger logger= Logger.getRootLogger();
	
	public static void main(String[] args) throws BankException {
		
		PropertyConfigurator.configure("resources/log4j.properties");
		
		BankBean bankBean=null;
		
		int option=0;
		
		while(true)
		{
			

			System.out.println();
			System.out.println();
			System.out.println("   BANK APPLICATION   ");
			System.out.println("__________________________________");
			System.out.println("1- Add Account");
			System.out.println("2- View Account Details By Account Number");
			System.out.println("3- Deposit Money");
			System.out.println("4- Withdraw Money");
			System.out.println("5- De-Activate Account By Account Number");
			System.out.println("6- Exit");
			System.out.println("__________________________________");
			System.out.println(" Select An Option ");
		
		
			try
			{
			
				option =scan.nextInt();
				switch(option)
				{
				case 1: while(bankBean==null)
						{
							bankBean = populateDonorBean();
						}
						try
						{
							bankService = new BankServiceImpl();
							bankService.createAccount(bankBean);
					
						}
						finally
						{
							
							bankService=null;
							bankBean = null;
						}
			
							break;
							
							
				case 2:		
							try
							{
								bankService = new BankServiceImpl();
								System.out.println("Enter Account Number To View Details: ");
								String id=scan.next();
								bankBean=bankService.viewAccountDetails(id);
								System.out.println("Account Number is: "+bankBean.getAccountNo());
								System.out.println("Account Holder Name is: "+bankBean.getName());
								System.out.println("Mobile Number Linked To This Account is: "+bankBean.getMobileNum());
								System.out.println("Current Account Balance is: "+bankBean.getBalance());
							}
							catch(Exception e)
							{
								e.printStackTrace();
							}
							finally
							{
								
								bankService=null;
								bankBean = null;
							}
							
							break;
					
					
				case 3:		
							try
							{
								bankService= new BankServiceImpl();
								System.out.println("Enter Account Number to Deposit Amount");
								String accountNum=scan.next();
								System.out.println("Enter Amount");
								double amount=scan.nextDouble();
			
								bankService.deposit(amount,accountNum);
								System.out.println("Account Number "+accountNum+" is credited with amount of RS "+amount);
								
							}
							catch(Exception e)
							{
								e.printStackTrace();
							}
							finally
							{
								bankService=null;
							}
							break;
					
				case 4:		
						try
						{
							bankService= new BankServiceImpl();
							System.out.println("Enter Account Number from which to want to withdraw");
							String accountNum=scan.next();
							System.out.println("Enter Amount to withdraw");
							double amount=scan.nextDouble();
	
							bankService.withdraw(amount,accountNum);
							System.out.println("Account Number "+accountNum+" is debited with amount of RS "+amount);
						
						}
						catch(Exception e)
						{
							e.printStackTrace();
						}
						finally
						{
							bankService=null;
						}
						break;

					
				case 5:  	
							try
							{
								bankService = new BankServiceImpl();
								System.out.println("Enter Account Number To Delete Account: ");
								String accountNo=scan.next();
								bankService.deleteAccount(accountNo);
								System.out.println("Account Deleted Successfully !!!");
							}
							catch(Exception e)
							{
								e.printStackTrace();
							}
							finally
							{
								bankService = null;
							}
							break;
					
				case 6: 	System.exit(0);
							break;
				default: 
							System.out.println("Please Select Valid Option ");
				}
			}
			catch(Exception e)
			{
				e.printStackTrace();
				System.err.println(e);
			}
	}
}
	
	

	private static BankBean populateDonorBean()  {
		BankBean bankBean = new BankBean();
		
		System.out.println("Enter Details: ");
		

		System.out.println("Enter Account Holder Name: ");
		bankBean.setName(scan.next());
		
		System.out.println("Enter Phone Number: ");
		bankBean.setMobileNum(scan.next());
		
		System.out.println("Enter Minimum Balance: ");
		try
		{
			bankBean.setBalance(scan.nextDouble());
		}
		catch(InputMismatchException ioe)
		{
			scan.nextDouble();
			ioe.printStackTrace();
			System.err.println("Please Enter the numeric value for Donation Amount, Try Again !!!");
		}
		
		bankServiceImpl=new BankServiceImpl();
		
		try
		{
		
			bankServiceImpl.validateDetails(bankBean);
			return bankBean;
		}
		catch(Exception e)
		{
			System.out.println("sadfasd");
		}
		
		
	return null;
	}
	

}
