package com.cg.bank.service;

import java.io.IOException;
import java.sql.SQLException;

import com.cg.bank.bean.BankBean;

public interface IBankService {

	public String createAccount(BankBean bankbean) throws IOException;
	
	public BankBean viewAccountDetails(String accountNo) throws IOException;
	
	public void deposit(double amount,String accountNo) throws IOException, SQLException;
	
	public void withdraw(double amount, String aacountNo) throws IOException, SQLException;
	
	public void deleteAccount(String accountNo) throws SQLException, IOException;

	

	
	
	
}
