package com.cg.bank.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.bank.bean.BankBean;
import com.cg.bank.dao.BankDAOImpl;
import com.cg.bank.dao.IBankDAO;
import com.cg.bank.exception.BankException;


public class BankServiceImpl implements IBankService {
	
	IBankDAO bankdao= new BankDAOImpl();

	@Override
	public String createAccount(BankBean bankBean) throws IOException {
		
		String donorSeq;
		donorSeq=bankdao.createAccount(bankBean);
		return donorSeq;
	}

	@Override
	public BankBean viewAccountDetails(String accountNo) throws IOException {
		
		BankBean  bank;
		bank=bankdao.viewAccountDetails(accountNo);
		return bank;
	
	}

	@Override
	public void deposit(double amount,String accountNo) throws IOException, SQLException {
		
		String accNo=accountNo;
		double damount=amount;
		bankdao.deposit(damount,accNo);
	
	}

	@Override
	public void withdraw(double amount,String accountNo) throws IOException, SQLException {
		
		String accNo=accountNo;
		double damount=amount;
		bankdao.withdraw(damount,accNo);
		
		
	}

	@Override
	public void deleteAccount(String accountNo) throws SQLException, IOException {
		
		bankdao.deleteAccount(accountNo);	
	}
	
	

	public void validateDetails(BankBean bankBean) throws BankException {
		
		List<String> validationErrors = new ArrayList<String>();
		
		
		if(!(isValidName(bankBean.getName())))
		{
			validationErrors.add("\n Donor Name should be in Alphabets and Minimum 3 character long \n");
		}
		
	
		if(!(isValidPhoneNumber(bankBean.getMobileNum())))
		{
			validationErrors.add("\n Phone Number Should be in 10 digits \n");
		}
		
		if(!(isValidBalance(bankBean.getBalance())))
		{
			validationErrors.add("\n Please provide Valid Amount \n");
		}
		
		if(!(validationErrors.isEmpty()))
		{
			throw new BankException(validationErrors+"Please Enter Valid User Details ");
		}
	}
		private boolean isValidBalance(double balance)
		{
			return balance>0;
		}
		
		
		private boolean isValidPhoneNumber(String phoneNumber)
		{
			Pattern phonePattern = Pattern.compile("^[6-9][0-9]{9}$");
			Matcher phoneMatcher = phonePattern.matcher(phoneNumber);
			return phoneMatcher.matches();
		}
		
		private boolean isValidName(String name)
		{
			
			Pattern namePattern = Pattern.compile("^[A-Z][a-z]{3,}$");
			Matcher nameMatcher = namePattern.matcher(name);
			return nameMatcher.matches();
		}
	}
