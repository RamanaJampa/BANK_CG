package com.cg.bank.dao;

import java.io.IOException;
import java.sql.SQLException;

import com.cg.bank.bean.BankBean;

public interface IBankDAO {

	public String createAccount(BankBean bankbean) throws IOException;
	
	public BankBean viewAccountDetails(String accountNo) throws IOException;
	
	public void deposit(double amount, String accNo) throws IOException, SQLException;
	
	public void withdraw(double amount, String accNo) throws IOException, SQLException;
	
	public void deleteAccount(String accountNo) throws SQLException, IOException;

	
}
