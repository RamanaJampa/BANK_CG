package com.cg.bank.dao;

public interface QueryMapper {
	
	public static final String Add_Details="insert into bank_details values(accountNum_sequence.nextval,?,?,?)";
	
	public static final String View_Details="select * from bank_details where accountNum = ? ";
	
	public static final String Deposit_Money="update bank_details set balance=balance+ ? where accountNum = ? ";
	
	public static final String Withdraw_Money="update bank_details set balance=balance- ? where accountNum = ? ";
	
	public static final String Delete_Account="delete bank_details where accountNum = ?";

}
