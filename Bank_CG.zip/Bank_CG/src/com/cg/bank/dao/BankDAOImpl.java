package com.cg.bank.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.management.Query;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.bank.bean.BankBean;
import com.cg.bank.util.DBConnection;

public class BankDAOImpl implements IBankDAO{
	
	Logger logger=Logger.getRootLogger();
	
	public BankDAOImpl()
	{
	PropertyConfigurator.configure("resources/log4j.properties");
	
	}

	@Override
	public String createAccount(BankBean bankBean) throws IOException {
		
		Connection connection= DBConnection.getConnection();
		
		PreparedStatement ps=null;
		ResultSet rs=null;
		int queryResult=0;
	
		try
		{
			
			ps=connection.prepareStatement(QueryMapper.Add_Details);
			ps.setString(1,bankBean.getName());
			ps.setString(2,bankBean.getMobileNum());
			ps.setDouble(3,bankBean.getBalance());
			queryResult=ps.executeUpdate();
			
			/*PreparedStatement st= connection.prepareStatement("insert into min_balance values(accountNumMin_sequence.nextVal,?)");
			st.setDouble(1,bankBean.getBalance());
			st.executeUpdate();*/
			
			if(queryResult==0)
			{
				logger.error("Insertion Failed !!! \n Please Try After Sometime");
			}
			else
			{
				logger.info("Values Inserted Successfully");
			}
		}
		catch(Exception se)
		{
			se.printStackTrace();
		}
		
		return null;
	}

	@Override
	public BankBean viewAccountDetails(String accountNo) throws IOException {
		
		Connection con=DBConnection.getConnection();
		BankBean bankBean = new BankBean();
		
		try
		{
			String account_num = accountNo;
			PreparedStatement st= con.prepareStatement(QueryMapper.View_Details);
			st.setString(1,account_num);
			ResultSet rs=st.executeQuery();
			
			 if(rs==null)
			{
				logger.error("Data Cannot Be Fetched From Database !!!\n Please Try After Sometime. ");
			}
			
			else if(rs.next())
			{
				bankBean.setAccountNo(rs.getString(1));
				bankBean.setName(rs.getString(2));
				bankBean.setMobileNum(rs.getString(3));
				bankBean.setBalance(rs.getDouble(4));
			}
			
			
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return bankBean;
	}

	@Override
	public void deposit(double amount,String accountNo) throws IOException, SQLException {
		
		Connection con=DBConnection.getConnection();
		try
		{
			PreparedStatement ps=con.prepareStatement(QueryMapper.Deposit_Money);
			ps.setDouble(1,amount);
			ps.setString(2,accountNo);
			int query=ps.executeUpdate();
			
			if(query==0)
			{
				
				logger.error("Money Cannot Be Deposited !!!\n Please Try After Sometime.");
			}
			else
			{
				logger.info("Money Deposited Successfully");
			}
		}
		finally
		{
		  
		}
		
		
		
	}

	@Override
	public void withdraw(double amount,String accountNo) throws IOException, SQLException {
		
		Connection con=DBConnection.getConnection();
		try
		{
			PreparedStatement ps=con.prepareStatement(QueryMapper.Withdraw_Money);
			ps.setDouble(1,amount);
			ps.setString(2,accountNo);
			int query=ps.executeUpdate();
			
			
			if(query==0)
			{
				logger.error("Money Cannot Be Withdrawn !!! \n Please Try After Sometime");
			}
			else
			{
				logger.info("Transaction Successfull");
			}
		}
		finally
		{
		  
		}
	}

	@Override
	public void deleteAccount(String accountNo) throws SQLException, IOException {
		
		Connection con=DBConnection.getConnection();
		try
		{
			PreparedStatement ps=con.prepareStatement(QueryMapper.Delete_Account);
			ps.setString(1,accountNo);
			int query =ps.executeUpdate();
			
			if(query==0)
			{
				logger.error("Unable To Withdraw Money");
			}
			else
			{
				logger.info("Money Withdrawn Successfully");
			}
		}
		finally
		{
		  
		}
		
		
	}

}
