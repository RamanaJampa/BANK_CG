package com.cg.donor.test;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.sql.Connection;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.jupiter.api.Test;

import com.cg.bank.dao.BankDAOImpl;
import com.cg.bank.exception.BankException;
import com.cg.bank.util.DBConnection;

import junit.framework.Assert;

class DBConnectionTest {

	static BankDAOImpl bankdao;
	static Connection con;

	@BeforeClass
	public static void initialise() {
		bankdao = new BankDAOImpl();
		con = null;
	}

	@Before
	public void beforeEachTest() {
		System.out.println("----Starting DBConnection Test Case----\n");
	}

	
	@Test
	public void test() throws BankException, IOException {
		Connection con = DBConnection.getConnection();
		Assert.assertNotNull(con);
	}

	@After
	public void afterEachTest() {
		System.out.println("----End of DBConnection Test Case----\n");
	}

	@AfterClass
	public static void destroy() {
		System.out.println("\t----End of Tests----");
		bankdao = null;
		con = null;
	}

}

