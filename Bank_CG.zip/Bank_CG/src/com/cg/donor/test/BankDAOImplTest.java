package com.cg.donor.test;




import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;


import java.io.IOException;

import org.junit.Test;

import com.cg.bank.bean.BankBean;
import com.cg.bank.dao.BankDAOImpl;

class BankDAOImplTest {
	
		static BankDAOImpl bankdao;
		static BankBean bankBean;
		

	@Test
	void testCreateAccount() throws IOException {
		
		bankdao=new BankDAOImpl();
		bankBean=new BankBean();
		bankBean.setName("Ramana");
		bankBean.setMobileNum("8527419630");
		bankBean.setBalance(15000);
		
		assertEquals(null,bankdao.createAccount(bankBean));
		
	}

	@Test
	void testViewAccountDetails() throws IOException {
		bankdao=new BankDAOImpl();
		bankBean=new BankBean();
		assertEquals("Sufall",bankdao.viewAccountDetails("183822").getName());
	}

	@Test
	void testDeposit() {

		bankdao=new BankDAOImpl();
		bankBean=new BankBean();
		
		
	}

	@Test
	void testWithdraw() {
		
	}

	@Test
	void testDeleteAccount() {
		

	}
	
}
