create table bank_details(accountnum varchar2(15),name varchar2(15),phonenumber number(10),balance number(20));


create SEQUENCE accountnum_sequence start with 183802;